from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import json
import os
from datetime import datetime
from typing import List, Dict, Any
import uvicorn
from geopy.distance import geodesic

# Инициализация приложения
app = FastAPI(
    title="API национального парка 'Приэльбрусье'",
    description="API для управления экологическим туризмом и проверки доступа",
    version="1.0.0"
)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Пути к файлам данных
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "frontend", "data"))

# Загрузка данных
def load_json_file(filename: str) -> Dict:
    filepath = os.path.join(DATA_DIR, filename)
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Загружаем данные
attractions_data = load_json_file("attractions.json")
seasonal_rules = load_json_file("seasonal_rules.json")
zone_rules = load_json_file("zone_rules.json")
functional_zones = load_json_file("functional_zones.geojson")
infrastructure_data = load_json_file("infrastructure.json")
example_routes = load_json_file("example_routes.json")
transport_rules = load_json_file("transport_rules.json")

TRAIL_DIFFICULTY_MULTIPLIER = {
    "easy": 1.0,
    "medium": 0.8,
    "hard": 0.5
}

EXPERIENCE_LEVELS = {
    "beginner": {"max_daily_km": 10.0, "allowed_difficulties": ["easy"]},
    "intermediate": {"max_daily_km": 15.0, "allowed_difficulties": ["easy", "medium"]},
    "advanced": {"max_daily_km": 25.0, "allowed_difficulties": ["easy", "medium", "hard"]}
}

# Корневой эндпоинт
@app.get("/")
async def root():
    return {
        "message": "API национального парка 'Приэльбрусье' работает",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "endpoints": {
            "check_access": "/check_access?zone_type={type}&group_size={size}&month={month}",
            "attractions": "/attractions",
            "zones": "/zones",
            "generate_smart_route": "/generate_smart_route",
            "health": "/health"
        }
    }

# Проверка доступа к зоне
@app.get("/check_access")
async def check_access(zone_type: str, group_size: int, month: int):
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="Месяц должен быть в диапазоне от 1 до 12")
    
    if group_size <= 0 or group_size > 100:
        raise HTTPException(status_code=400, detail="Размер группы должен быть 1-100 человек")
    
    if zone_type not in zone_rules:
        return {
            "allowed": False,
            "reason": f"Тип зоны '{zone_type}' не найден"
        }
    
    zone_rule = zone_rules[zone_type]
    
    if group_size > zone_rule["max_group_size"]:
        return {
            "allowed": False,
            "reason": f"Группа превышает лимит ({group_size} > {zone_rule['max_group_size']})"
        }
    
    for season_name, season_data in seasonal_rules.get("seasonal_restrictions", {}).items():
        if month in season_data.get("months", []) and zone_type in season_data.get("restricted_zones", []):
            return {
                "allowed": False,
                "reason": f"Зона закрыта в {season_name}: {season_data.get('reason', 'сезонные ограничения')}"
            }
    
    if month not in zone_rule.get("allowed_months", list(range(1, 13))):
        return {
            "allowed": False,
            "reason": f"Зона недоступна в выбранный месяц ({month})"
        }
    
    if zone_rule.get("requires_permission", False):
        return {
            "allowed": True,
            "reason": "Требуется разрешение администрации"
        }
    
    if zone_rule.get("requires_guide", False):
        return {
            "allowed": True,
            "reason": "Требуется сопровождение гида"
        }
    
    return {"allowed": True, "reason": "Доступ разрешен"}

@app.get("/generate_smart_route")
async def generate_smart_route(
    theme: str = "",  
    experience_level: str = "beginner",
    month: int = 7,
    group_size: int = 5,
    transport_type: str = "пеший"
):
    if experience_level not in EXPERIENCE_LEVELS:
        raise HTTPException(status_code=400, detail=f"Недопустимый уровень опыта. Доступные: {list(EXPERIENCE_LEVELS.keys())}")
    
    user_config = EXPERIENCE_LEVELS[experience_level]
    base_max_km = user_config["max_daily_km"]
    allowed_difficulties = user_config["allowed_difficulties"]
    
    points = attractions_data.get("points", [])
    
    # 🔥 1. Фильтр по теме (используем поле theme из JSON)
    if theme and theme not in ("", "все"):
        valid_points = [p for p in points if p.get("theme") == theme]
    else:
        valid_points = points
        
    if not valid_points:
        raise HTTPException(status_code=404, detail="Точки не найдены")
        
    #  Фильтр по сложности
    filtered_points = [p for p in valid_points if p.get("trail_difficulty", "easy") in allowed_difficulties]
    warnings = []
    
    excluded = len(valid_points) - len(filtered_points)
    if excluded > 0:
        warnings.append(f"⚠️ {excluded} точек исключено из-за сложности (ваш уровень: {experience_level})")
        
    if len(filtered_points) < 2:
        warnings.append("⚠️ Рекомендуется повысить уровень опыта или выбрать другую тему")
        filtered_points = valid_points  # Возвращаем что есть
        
    route_points = []
    current_distance = 0.0
    
    for i, p in enumerate(filtered_points):
        if i == 0:
            route_points.append(p)
            continue
            
        last_p = route_points[-1]
        dist = geodesic(
            (last_p["coordinates"][1], last_p["coordinates"][0]),
            (p["coordinates"][1], p["coordinates"][0])
        ).km
        
        if current_distance + dist <= base_max_km:
            route_points.append(p)
            current_distance += dist
        else:
            break  # Лимит км превышен
            
    #  4. Расчёт корректировки лимита по сложности выбранного маршрута
    if route_points:
        max_diff = max((p.get("trail_difficulty", "easy") for p in route_points), 
                       key=lambda d: {"easy": 0, "medium": 1, "hard": 2}[d])
        multiplier = TRAIL_DIFFICULTY_MULTIPLIER.get(max_diff, 1.0)
        effective_max_km = base_max_km * multiplier
    else:
        max_diff, multiplier, effective_max_km = "easy", 1.0, base_max_km
        
    # Предупреждение о наборе высоты
    if len(route_points) >= 2:
        elev_gain = abs(route_points[-1]["elevation_m"] - route_points[0]["elevation_m"])
        if elev_gain > 1000:
            warnings.append(f"️ Набор высоты {elev_gain} м > 1000 м. Рекомендуется разбить этап.")
    else:
        elev_gain = 0
        
    return {
        "route_name": f"Эко-маршрут «{theme.capitalize() if theme else 'Обзорный'}» ({experience_level})",
        "experience_level": experience_level,
        "base_daily_limit_km": base_max_km,
        "effective_daily_limit_km": round(effective_max_km, 1),
        "difficulty_adjustment": f"{multiplier*100:.0f}% (из-за {max_diff} сложности)",
        "points": [
            {
                "name": p["name"],
                "coordinates": p["coordinates"],  # 🔥 Отдаём как в JSON [долгота, широта]
                "elevation_m": p["elevation_m"],
                "trail_difficulty": p.get("trail_difficulty", "easy"),
                "zone_type": p["zone_type"],
                "warning": "Требуется гид" if zone_rules.get(p["zone_type"], {}).get("requires_guide") else None
            }
            for p in route_points
        ],
        "total_distance_km": round(current_distance, 1),
        "elevation_gain_m": elev_gain,
        "warnings": warnings if warnings else ["✅ Маршрут полностью соответствует вашему уровню"],
        "recommendations": [
            f"Ваш уровень: {experience_level}. Базовый лимит: {base_max_km} км/день",
            f"С учётом сложности троп: {round(effective_max_km, 1)} км/день"
        ]
    }

# Получение всех достопримечательностей
@app.get("/attractions")
async def get_attractions(
    zone_type: str = None,
    category: str = None,
    min_elevation: int = None,
    max_elevation: int = None,
    # 🆕 NEW: Фильтр по сложности троп
    trail_difficulty: str = None
):
    points = attractions_data.get("points", [])
    filtered_points = points
    
    if zone_type:
        filtered_points = [p for p in filtered_points if p.get("zone_type") == zone_type]
    
    if category:
        filtered_points = [p for p in filtered_points if p.get("category") == category]
    
    if min_elevation is not None:
        filtered_points = [p for p in filtered_points if p.get("elevation_m", 0) >= min_elevation]
    
    if max_elevation is not None:
        filtered_points = [p for p in filtered_points if p.get("elevation_m", float('inf')) <= max_elevation]
    
    if trail_difficulty:
        filtered_points = [p for p in filtered_points if p.get("trail_difficulty") == trail_difficulty]
    
    return {
        "points": filtered_points,
        "total": len(filtered_points),
        "filters_applied": {
            "zone_type": zone_type,
            "category": category,
            "min_elevation": min_elevation,
            "max_elevation": max_elevation,
            "trail_difficulty": trail_difficulty  # 🆕 NEW
        }
    }

# Получение конкретной достопримечательности
@app.get("/attractions/{name}")
async def get_attraction_by_name(name: str):
    points = attractions_data.get("points", [])
    
    for point in points:
        if point.get("name") == name:
            zone_type = point.get("zone_type")
            zone_rule = zone_rules.get(zone_type, {})
            
            point_with_access = dict(point)
            point_with_access["access_rules"] = {
                "max_group_size": zone_rule.get("max_group_size", "не определено"),
                "requires_permission": zone_rule.get("requires_permission", False),
                "requires_guide": zone_rule.get("requires_guide", False),
                "allowed_months": zone_rule.get("allowed_months", []),
                "allowed_transport": zone_rule.get("allowed_transport", [])
            }
            
            # 🆕 NEW: Рекомендации по уровню опыта
            difficulty = point.get("trail_difficulty", "easy")
            if difficulty == "hard":
                point_with_access["recommended_experience"] = "advanced"
            elif difficulty == "medium":
                point_with_access["recommended_experience"] = "intermediate"
            else:
                point_with_access["recommended_experience"] = "beginner"
            
            return point_with_access
    
    raise HTTPException(status_code=404, detail=f"Достопримечательность '{name}' не найдена")

# Получение функциональных зон
@app.get("/zones")
async def get_zones():
    return functional_zones

# Получение информации о зонах
@app.get("/zones/{zone_type}")
async def get_zone_info(zone_type: str):
    if zone_type not in zone_rules:
        raise HTTPException(status_code=404, detail=f"Тип зоны '{zone_type}' не найден")
    
    zone_info = zone_rules[zone_type]
    seasonal_info = []
    
    for season_name, season_data in seasonal_rules.get("seasonal_restrictions", {}).items():
        if zone_type in season_data.get("restricted_zones", []):
            seasonal_info.append({
                "season": season_name,
                "months": season_data.get("months", []),
                "reason": season_data.get("reason", "")
            })
    
    return {
        "zone_type": zone_type,
        "rules": zone_info,
        "seasonal_restrictions": seasonal_info
    }

# Получение инфраструктуры
@app.get("/infrastructure")
async def get_infrastructure(zone_type: str = None):
    items = infrastructure_data.get("infrastructure", [])
    
    if zone_type:
        items = [i for i in items if i.get("zone_type") == zone_type]
    
    return {"infrastructure": items, "total": len(items)}

# Получение правил
@app.get("/rules/{rule_type}")
async def get_rules(rule_type: str):
    if rule_type == "seasonal":
        return seasonal_rules
    elif rule_type == "transport":
        return transport_rules
    elif rule_type == "legal":
        legal_basis = load_json_file("legal_basis.json")
        return legal_basis
    else:
        raise HTTPException(status_code=404, detail=f"Тип правил '{rule_type}' не найден")

# 🆕 NEW: Эндпоинт для получения доступных уровней опыта
@app.get("/experience-levels")
async def get_experience_levels():
    """
    🆕 NEW: Возвращает информацию о уровнях опыта и их ограничениях
    """
    return {
        "levels": EXPERIENCE_LEVELS,
        "difficulty_multipliers": TRAIL_DIFFICULTY_MULTIPLIER,
        "description": {
            "beginner": "Новичок: до 10 км/день, только лёгкие тропы",
            "intermediate": "Средний: до 15 км/день, лёгкие и средние тропы",
            "advanced": "Опытный: до 25 км/день, любые тропы"
        }
    }

# Проверка здоровья API
@app.get("/health")
async def health_check():
    data_files = {
        "attractions": bool(attractions_data),
        "seasonal_rules": bool(seasonal_rules),
        "zone_rules": bool(zone_rules),
        "functional_zones": bool(functional_zones),
        "infrastructure": bool(infrastructure_data),
        "example_routes": bool(example_routes),
        "transport_rules": bool(transport_rules)
    }
    
    all_files_loaded = all(data_files.values())
    
    return {
        "status": "healthy" if all_files_loaded else "degraded",
        "timestamp": datetime.now().isoformat(),
        "data_files": data_files,
        "missing_files": [k for k, v in data_files.items() if not v]
    }

# Статистика
@app.get("/stats")
async def get_statistics():
    points = attractions_data.get("points", [])
    infrastructure = infrastructure_data.get("infrastructure", [])
    
    zone_stats = {}
    for point in points:
        zone_type = point.get("zone_type")
        if zone_type:
            zone_stats[zone_type] = zone_stats.get(zone_type, 0) + 1
    
    category_stats = {}
    for point in points:
        category = point.get("category")
        if category:
            category_stats[category] = category_stats.get(category, 0) + 1
    
    # 🆕 NEW: Статистика по сложности троп
    difficulty_stats = {}
    for point in points:
        difficulty = point.get("trail_difficulty", "not_set")
        difficulty_stats[difficulty] = difficulty_stats.get(difficulty, 0) + 1
    
    elevations = [p.get("elevation_m", 0) for p in points if p.get("elevation_m")]
    
    return {
        "attractions": {
            "total": len(points),
            "by_zone": zone_stats,
            "by_category": category_stats,
            "by_difficulty": difficulty_stats,  # 🆕 NEW
            "elevation": {
                "min": min(elevations) if elevations else 0,
                "max": max(elevations) if elevations else 0,
                "avg": sum(elevations) / len(elevations) if elevations else 0
            }
        },
        "infrastructure": {
            "total": len(infrastructure),
            "by_type": {}
        },
        "zones": {
            "total": len(zone_rules),
            "list": list(zone_rules.keys())
        }
    }

if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=True
    )