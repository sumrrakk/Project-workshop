import json
import os

def is_point_accessible(zone_type: str, group_size: int, month: int, zone_rules, seasonal_rules) -> dict:
    """
    Проверяет можно ли посетить точку с заданными параметрами.
    
    Args:
        zone_type: тип зоны
        group_size: размер группы
        month: месяц (1-12)
        zone_rules: словарь с правилами зон
        seasonal_rules: словарь с сезонными правилами
    
    Returns:
        dict: {"allowed": bool, "reason": str}
    """
    if zone_type not in zone_rules:
        return {"allowed": False, "reason": f"Тип зоны '{zone_type}' не найден"}
    
    if group_size > zone_rules[zone_type]["max_group_size"]:
        return {
            "allowed": False,
            "reason": f"Группа превышает лимит ({group_size} > {zone_rules[zone_type]['max_group_size']})"
        }
    
    # Проверка сезонных ограничений
    for season_data in seasonal_rules.get("seasonal_restrictions", {}).values():
        if month in season_data.get("months", []) and zone_type in season_data.get("restricted_zones", []):
            return {"allowed": False, "reason": f"Зона закрыта в этот сезон: {season_data.get('reason', '')}"}
    
    return {"allowed": True, "reason": "Доступ разрешен"}

# Пример использования
if __name__ == "__main__":
    # Загрузка данных
    current_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(current_dir, "data")
    
    with open(os.path.join(data_dir, 'zone_rules.json'), 'r', encoding='utf-8') as f:
        ZONE_RULES = json.load(f)
    
    with open(os.path.join(data_dir, 'seasonal_rules.json'), 'r', encoding='utf-8') as f:
        SEASONAL_RULES = json.load(f)
    
    # Тесты
    tests = [
        ("заповедная", 10, 7),  # Лето, группа 10 человек
        ("рекреационная", 20, 7),  # Лето, группа 20 человек
        ("особо охраняемая", 5, 1),  # Зима, группа 5 человек
        ("рекреационная", 35, 7),  # Лето, группа 35 человек (превышение)
    ]
    
    for zone_type, group_size, month in tests:
        result = is_point_accessible(zone_type, group_size, month, ZONE_RULES, SEASONAL_RULES)
        print(f"{zone_type}, группа {group_size}, месяц {month}: {result}")