// Конфигурация приложения
const CONFIG = {
    API_URL: 'http://localhost:8000',
    MAP_CENTER: [43.35, 42.48],
    MAP_ZOOM: 10,
    ZONE_COLORS: {
        'рекреационная': '#2ecc71',
        'особо охраняемая': '#f39c12',
        'заповедная': '#e74c3c',
        'традиционного природопользования': '#3498db'
    },
    ICON_COLORS: {
        'инфраструктура': '#9b59b6',
        'природные объекты': '#1abc9c',
        'культурные объекты': '#e67e22',
        'географические объекты': '#34495e'
    }
};

// Глобальные переменные
let map = null;
let attractions = [];
let zones = [];
let markers = {};
let currentMode = 'map';
let routeLayer = null; // 

// Инициализация приложения
document.addEventListener('DOMContentLoaded', () => {
    console.log('Приложение национального парка инициализируется...');

    // Инициализация элементов
    initElements();

    // Инициализация карты
    initMap();

    // Проверка API
    checkAPIStatus();

    // Загрузка данных
    loadAttractions();
    loadZones();

    // Обновление времени
    updateTime();
    setInterval(updateTime, 60000);

    // Установка обработчиков событий
    setupEventListeners();
});

// Инициализация DOM элементов
function initElements() {
    console.log('Инициализация элементов интерфейса...');

    // Обновление значения ползунка
    const groupSizeSlider = document.getElementById('groupSize');
    const groupSizeValue = document.getElementById('groupSizeValue');

    groupSizeSlider.addEventListener('input', () => {
        groupSizeValue.textContent = groupSizeSlider.value;
    });
}

// Инициализация карты
function initMap() {
    console.log('Инициализация карты...');

    // Создание карты
    map = L.map('map').setView(CONFIG.MAP_CENTER, CONFIG.MAP_ZOOM);

    // Добавление базового слоя
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18
    }).addTo(map);

    // Добавление элементов управления
    initMapControls();

    console.log('Карта успешно инициализирована');
}

// Инициализация элементов управления картой
function initMapControls() {
    // Кнопки масштабирования
    document.getElementById('zoomIn').addEventListener('click', () => {
        map.zoomIn();
    });

    document.getElementById('zoomOut').addEventListener('click', () => {
        map.zoomOut();
    });

    // Кнопка определения местоположения
    document.getElementById('locateMe').addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const { latitude, longitude } = position.coords;
                map.setView([latitude, longitude], 13);
                L.marker([latitude, longitude])
                    .addTo(map)
                    .bindPopup('Ваше местоположение')
                    .openPopup();
            });
        }
    });
}

// Настройка обработчиков событий
function setupEventListeners() {
    console.log('Настройка обработчиков событий...');

    // Переключение боковой панели
    document.getElementById('toggleSidebar').addEventListener('click', () => {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('open');
    });

    // Навигация по режимам
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            // Обновление активной кнопки
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Изменение режима
            currentMode = btn.dataset.mode;
            switchMode(currentMode);
        });
    });

    // Проверка доступа
    document.getElementById('generateRouteBtn')?.addEventListener('click', generateSmartRoute);
    // Обновление достопримечательностей
    document.getElementById('refreshAttractions').addEventListener('click', loadAttractions);

    // Поиск достопримечательностей
    document.getElementById('searchAttractions').addEventListener('input', searchAttractions);

    // Закрытие панели информации
    document.getElementById('closeInfo').addEventListener('click', () => {
        document.getElementById('infoContainer').style.display = 'none';
    });

    // Фильтры
    document.querySelectorAll('.filter-item input').forEach(filter => {
        filter.addEventListener('change', updateFilters);
    });
}

// Переключение режимов
function switchMode(mode) {
    console.log(`Переключение в режим: ${mode}`);

    // Скрыть все контейнеры
    document.getElementById('mapContainer').style.display = 'none';
    document.getElementById('infoContainer').style.display = 'none';
    document.getElementById('listContainer').style.display = 'none';

    // Показать соответствующий контейнер
    switch (mode) {
        case 'map':
            document.getElementById('mapContainer').style.display = 'block';
            break;
        case 'attractions':
            document.getElementById('listContainer').style.display = 'block';
            showAttractionsList();
            break;
        case 'routes':
            document.getElementById('infoContainer').style.display = 'block';
            showRoutesInfo();
            break;
        case 'check':
            document.getElementById('infoContainer').style.display = 'block';
            showAccessCheckInfo();
            break;
    }

    // Обновление заголовка
    const titles = {
        'map': 'Карта национального парка',
        'attractions': 'Достопримечательности',
        'routes': 'Маршруты и правила',
        'check': 'Проверка доступа'
    };

    document.getElementById('infoTitle').textContent = titles[mode] || 'Информация';
}

// Проверка статуса API
async function checkAPIStatus() {
    try {
        const response = await fetch(`${CONFIG.API_URL}/`);
        if (response.ok) {
            const data = await response.json();
            updateAPIStatus(true, data.message);
        } else {
            updateAPIStatus(false, 'API недоступен');
        }
    } catch (error) {
        updateAPIStatus(false, 'Ошибка подключения');
        console.error('Ошибка проверки API:', error);
    }
}

// Обновление статуса API в интерфейсе
function updateAPIStatus(online, message) {
    const statusElement = document.getElementById('apiStatus');
    const detailedStatus = document.getElementById('apiDetailedStatus');

    if (online) {
        statusElement.innerHTML = '<span style="color: #2ecc71">API ✓</span>';
        detailedStatus.textContent = 'подключен';
        detailedStatus.className = 'status-online';
    } else {
        statusElement.innerHTML = '<span style="color: #e74c3c">API ✗</span>';
        detailedStatus.textContent = 'не подключен';
        detailedStatus.className = 'status-offline';
    }
}

// Загрузка достопримечательностей
// Загрузка достопримечательностей из локального JSON
async function loadAttractions() {
    try {
        console.log('Загрузка достопримечательностей из JSON...');

        // Замените на:
        const response = await fetch('./data/attractions.json');
        if (!response.ok) throw new Error('Файл достопримечательностей не найден');

        const data = await response.json();
        attractions = data.points || [];

        // Обновление счетчика
        document.getElementById('attractionCount').textContent = attractions.length;

        // Отображение на карте
        displayAttractionsOnMap();

        // Обновление списка
        if (currentMode === 'attractions') {
            showAttractionsList();
        }

        console.log(`Загружено ${attractions.length} достопримечательностей`);
    } catch (error) {
        console.error('Ошибка загрузки достопримечательностей:', error);
        attractions = [];
        document.getElementById('attractionsList').innerHTML = `
            <div class="loading" style="color: #e74c3c;">
                Ошибка загрузки данных.
            </div>
        `;
    }
}

// Отображение достопримечательностей на карте
function displayAttractionsOnMap(showInfrastructure = true) {
    // Удаление старых маркеров
    if (markers.attractions) {
        markers.attractions.forEach(marker => map.removeLayer(marker));
    }
    markers.attractions = [];
    
    // 🔥 Фильтрация точек
    const filteredPoints = attractions.filter(attraction => {
        if (attraction.category === 'инфраструктура' && !showInfrastructure) {
            return false;
        }
        return true;
    });
    
    console.log('🔍 Точек на карте:', filteredPoints.length, '| Инфраструктура:', showInfrastructure ? 'вкл' : 'выкл');
    
    // Создание маркеров
    filteredPoints.forEach(attraction => {
        const [lng, lat] = attraction.coordinates;

        // Выбор иконки
        const iconHtml = (attraction.category === 'инфраструктура' || attraction.facility_type)
            ? `<i class="fas fa-home" style="color: #f39c12; font-size: 20px; text-shadow: 0 1px 3px rgba(0,0,0,0.5);"></i>`
            : `<i class="fas fa-mountain" style="color: #3498db; font-size: 20px; text-shadow: 0 1px 3px rgba(0,0,0,0.5);"></i>`;

        const icon = L.divIcon({
            className: 'custom-marker',
            html: iconHtml,
            iconSize: [30, 30],
            iconAnchor: [15, 15],
            popupAnchor: [0, -15]
        });

        const marker = L.marker([lat, lng], { icon })
            .addTo(map)
            .bindPopup(createAttractionPopup(attraction));

        marker.on('click', () => showAttractionInfo(attraction));
        markers.attractions.push(marker);
    });
}

// Создание всплывающего окна для достопримечательности
function createAttractionPopup(attraction) {
    return `
        <div class="popup-title">${attraction.name}</div>
        <div class="popup-details">
            <div><strong>Тип зоны:</strong> ${attraction.zone_type}</div>
            <div><strong>Высота:</strong> ${attraction.elevation_m} м</div>
            <div><strong>Категория:</strong> ${attraction.category}</div>
            <div><strong>Сложность:</strong> ${attraction.trail_difficulty || '?'}</div>
            <div>${attraction.description}</div>
        </div>
        <div class="popup-actions">
            <button class="popup-btn" onclick="checkAccessForAttraction('${attraction.name}', '${attraction.zone_type}')">
                Проверить доступ
            </button>
            <button class="popup-btn" onclick="window.open('https://www.google.com/search?q=${encodeURIComponent(attraction.name)}', '_blank')">
                Подробнее
            </button>
        </div>
    `;
}

// Показ информации о достопримечательности
function showAttractionInfo(attraction) {
    document.getElementById('infoContainer').style.display = 'block';
    document.getElementById('infoTitle').textContent = attraction.name;

    const infoContent = document.getElementById('infoContent');
    infoContent.innerHTML = `
        <div style="margin-bottom: 1rem;">
            <div style="display: flex; gap: 1rem; margin-bottom: 1rem;">
                <span class="zone-badge" style="background-color: ${CONFIG.ZONE_COLORS[attraction.zone_type]}">
                    ${attraction.zone_type}
                </span>
                <span><i class="fas fa-mountain"></i> ${attraction.elevation_m} м</span>
                <span><i class="fas fa-tag"></i> ${attraction.category}</span>
            </div>
            
            <h4 style="margin-bottom: 0.5rem;">Описание</h4>
            <p style="margin-bottom: 1rem;">${attraction.description}</p>
            
            <h4 style="margin-bottom: 0.5rem;">Образовательная ценность</h4>
            <p style="margin-bottom: 1rem;">${attraction.educational_value}</p>
            
            <h4 style="margin-bottom: 0.5rem;">Координаты</h4>
            <p>${attraction.coordinates[0].toFixed(4)}, ${attraction.coordinates[1].toFixed(4)}</p>
        </div>
        
        <div class="popup-actions">
            <button class="popup-btn" onclick="checkAccessForAttraction('${attraction.name}', '${attraction.zone_type}')" style="flex: 2;">
                <i class="fas fa-check-circle"></i> Проверить доступ
            </button>
            <button class="popup-btn" onclick="zoomToAttraction(${attraction.coordinates[0]}, ${attraction.coordinates[1]})">
                <i class="fas fa-search"></i> Найти на карте
            </button>
        </div>
    `;

    // Перемещение к достопримечательности на карте
    zoomToAttraction(attraction.coordinates[0], attraction.coordinates[1]);
}

function showAttractionInfoByName(name) {
    const found = attractions.find(p => p.name === name);
    if (found) {
        showAttractionInfo(found);
    }
}

// Приближение к достопримечательности
function zoomToAttraction(lat, lng) {
    map.setView([lng, lat], 13);
    document.getElementById('mapContainer').style.display = 'block';
}

// Показ списка достопримечательностей
function showAttractionsList() {
    const listContainer = document.getElementById('attractionsList');

    if (attractions.length === 0) {
        listContainer.innerHTML = '<div class="loading">Нет данных о достопримечательностях</div>';
        return;
    }

    let html = '';
    attractions.forEach(attraction => {
        html += `
            <div class="attraction-item" onclick="showAttractionInfo(${JSON.stringify(attraction).replace(/'/g, "\\'")})">
                <div class="attraction-name">${attraction.name}</div>
                <div class="attraction-details">
                    <span><i class="fas fa-map-marker-alt"></i> ${attraction.zone_type}</span>
                    <span><i class="fas fa-mountain"></i> ${attraction.elevation_m} м</span>
                    <span><i class="fas fa-tag"></i> ${attraction.category}</span>
                </div>
            </div>
        `;
    });

    listContainer.innerHTML = html;
}

// Поиск достопримечательностей
function searchAttractions() {
    const searchTerm = document.getElementById('searchAttractions').value.toLowerCase();
    const filteredAttractions = attractions.filter(attraction =>
        attraction.name.toLowerCase().includes(searchTerm) ||
        attraction.description.toLowerCase().includes(searchTerm) ||
        attraction.category.toLowerCase().includes(searchTerm)
    );

    const listContainer = document.getElementById('attractionsList');
    let html = '';

    filteredAttractions.forEach(attraction => {
        html += `
            <div class="attraction-item" onclick="showAttractionInfo(${JSON.stringify(attraction).replace(/'/g, "\\'")})">
                <div class="attraction-name">${attraction.name}</div>
                <div class="attraction-details">
                    <span><i class="fas fa-map-marker-alt"></i> ${attraction.zone_type}</span>
                    <span><i class="fas fa-mountain"></i> ${attraction.elevation_m} м</span>
                    <span><i class="fas fa-tag"></i> ${attraction.category}</span>
                </div>
            </div>
        `;
    });

    listContainer.innerHTML = html || '<div class="loading">Ничего не найдено</div>';
}

// Загрузка зон
// Загрузка зон из локального GeoJSON-файла
async function loadZones() {
    try {
        console.log('Загрузка зон из GeoJSON...');
        const response = await fetch('./data/functional_zones.geojson?v=' + Date.now());
        if (!response.ok) throw new Error('Файл зон не найден');
        const data = await response.json();
        zones = data.features || [];
        displayZonesOnMap();
        document.getElementById('zoneCount').textContent = zones.length;
        console.log(`Загружено ${zones.length} зон`);
    } catch (error) {
        console.error('Ошибка загрузки зон:', error);
        zones = [];
        // Не показываем alert, чтобы не мешать работе
        console.warn('Зоны не загружены, но карта продолжит работу');
    }
}


// Отображение зон на карте
function displayZonesOnMap() {
    // Удаление старых зон
    if (markers.zones) {
        markers.zones.forEach(zone => map.removeLayer(zone));
    }

    markers.zones = [];

    // Создание полигонов для каждой зоны
    zones.forEach(zone => {
        // ИСПРАВЛЕНО: корректное преобразование координат
        const coordinates = zone.geometry.coordinates[0].map(coord => [coord[1], coord[0]]);
        const zoneType = zone.properties.zone_type;

        // Создание полигона
        const polygon = L.polygon(coordinates, {
            color: CONFIG.ZONE_COLORS[zoneType] || '#95a5a6',
            fillColor: CONFIG.ZONE_COLORS[zoneType] || '#95a5a6',
            fillOpacity: 0.3,
            weight: 2
        }).addTo(map);

        // Добавление всплывающей подсказки
        polygon.bindPopup(`
            <div class="popup-title">${zone.properties.name}</div>
            <div class="popup-details">
                <div><strong>Тип зоны:</strong> ${zoneType}</div>
                <div>${zone.properties.description || ''}</div>
            </div>
        `);

        markers.zones.push(polygon);
    });
}

// Проверка доступа
async function checkAccess() {
    const zoneType = document.getElementById('zoneSelect').value;
    const groupSize = parseInt(document.getElementById('groupSize').value);
    const month = parseInt(document.getElementById('monthSelect').value);

    const resultDiv = document.getElementById('accessResult');
    resultDiv.className = 'access-result';
    resultDiv.innerHTML = '<div class="loading">Проверка...</div>';

    try {
        const response = await fetch(
            `${CONFIG.API_URL}/check_access?zone_type=${encodeURIComponent(zoneType)}&group_size=${groupSize}&month=${month}`
        );

        const result = await response.json();

        if (result.allowed) {
            resultDiv.className = 'access-result allowed';
            resultDiv.innerHTML = `
                <h4><i class="fas fa-check-circle"></i> Доступ разрешен</h4>
                <p>${result.reason}</p>
                <p><strong>Зона:</strong> ${zoneType}</p>
                <p><strong>Группа:</strong> ${groupSize} человек</p>
                <p><strong>Месяц:</strong> ${getMonthName(month)}</p>
            `;
        } else {
            resultDiv.className = 'access-result denied';
            resultDiv.innerHTML = `
                <h4><i class="fas fa-times-circle"></i> Доступ запрещен</h4>
                <p>${result.reason}</p>
                <p><strong>Зона:</strong> ${zoneType}</p>
                <p><strong>Группа:</strong> ${groupSize} человек</p>
                <p><strong>Месяц:</strong> ${getMonthName(month)}</p>
            `;
        }
    } catch (error) {
        resultDiv.className = 'access-result denied';
        resultDiv.innerHTML = `
            <h4><i class="fas fa-exclamation-triangle"></i> Ошибка</h4>
            <p>Не удалось проверить доступ. API сервер может быть недоступен.</p>
            <p><strong>Ошибка:</strong> ${error.message}</p>
        `;
        console.error('Ошибка проверки доступа:', error);
    }
}

// Проверка доступа для конкретной достопримечательности
async function checkAccessForAttraction(attractionName, zoneType) {
    const groupSize = prompt(`Введите размер группы для "${attractionName}":`, "10");
    if (!groupSize) return;

    const month = prompt("Введите месяц посещения (1-12):", "7");
    if (!month) return;

    const groupSizeNum = parseInt(groupSize);
    const monthNum = parseInt(month);

    if (isNaN(groupSizeNum) || isNaN(monthNum)) {
        alert('Пожалуйста, введите корректные числа');
        return;
    }

    try {
        const response = await fetch(
            `${CONFIG.API_URL}/check_access?zone_type=${encodeURIComponent(zoneType)}&group_size=${groupSizeNum}&month=${monthNum}`
        );

        const result = await response.json();

        if (result.allowed) {
            alert(`✓ Доступ к "${attractionName}" разрешен!\n\nГруппа: ${groupSizeNum} человек\nМесяц: ${getMonthName(monthNum)}\n\n${result.reason}`);
        } else {
            alert(`✗ Доступ к "${attractionName}" запрещен!\n\nГруппа: ${groupSizeNum} человек\nМесяц: ${getMonthName(monthNum)}\n\nПричина: ${result.reason}`);
        }
    } catch (error) {
        alert(`Ошибка при проверке доступа: ${error.message}`);
    }
}

// Показ информации о маршрутах
function showRoutesInfo() {
    const infoContent = document.getElementById('infoContent');
    infoContent.innerHTML = `
        <div style="margin-bottom: 1rem;">
            <h4 style="margin-bottom: 0.5rem;">Правила посещения парка</h4>
            <ul style="margin-left: 1.5rem; margin-bottom: 1rem;">
                <li>Соблюдайте установленные маршруты</li>
                <li>Уважайте дикую природу и животных</li>
                <li>Не оставляйте мусор</li>
                <li>Соблюдайте правила разведения костров</li>
                <li>Используйте разрешенный транспорт</li>
            </ul>
            
            <h4 style="margin-bottom: 0.5rem;">Рекомендуемые маршруты</h4>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
                <div style="border: 1px solid #ddd; border-radius: 6px; padding: 1rem;">
                    <h5>Экологический маршрут «Ледники и горы»</h5>
                    <p><strong>Сложность:</strong> Средняя</p>
                    <p><strong>Длина:</strong> 12.5 км</p>
                    <p><strong>Продолжительность:</strong> 6 часов</p>
                </div>
                <div style="border: 1px solid #ddd; border-radius: 6px; padding: 1rem;">
                    <h5>Семейный маршрут «Долина нарзанов»</h5>
                    <p><strong>Сложность:</strong> Легкая</p>
                    <p><strong>Длина:</strong> 5.2 км</p>
                    <p><strong>Продолжительность:</strong> 3 часа</p>
                </div>
            </div>
        </div>
    `;
}

// Показ информации о проверке доступа
function showAccessCheckInfo() {
    const infoContent = document.getElementById('infoContent');
    infoContent.innerHTML = `
        <div style="margin-bottom: 1rem;">
            <h4 style="margin-bottom: 0.5rem;">Как работает проверка доступа</h4>
            <p style="margin-bottom: 1rem;">Система проверяет возможность посещения зон на основе:</p>
            
            <ul style="margin-left: 1.5rem; margin-bottom: 1rem;">
                <li><strong>Размера группы</strong> - ограничения по максимальному количеству человек</li>
                <li><strong>Времени года</strong> - сезонные ограничения для защиты экосистем</li>
                <li><strong>Типа зоны</strong> - разные правила для разных зон парка</li>
                <li><strong>Требований к сопровождению</strong> - необходимость гида или разрешения</li>
            </ul>
            
            <p style="margin-bottom: 1rem;">Используйте форму в боковой панели для проверки доступа.</p>
            
            <h4 style="margin-bottom: 0.5rem;">Статистика правил</h4>
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem;">
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px;">
                    <h5>Максимальные группы</h5>
                    <p>Заповедная: 5 чел.</p>
                    <p>Особо охраняемая: 15 чел.</p>
                    <p>Рекреационная: 30 чел.</p>
                </div>
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 6px;">
                    <h5>Сезонные ограничения</h5>
                    <p>Весна: заповедные зоны</p>
                    <p>Лето: доступ открыт</p>
                    <p>Зима: большинство зон</p>
                </div>
            </div>
        </div>
    `;
}

// Обновление фильтров
function updateFilters() {
    const showZones = document.getElementById('filterZones').checked;
    const showInfrastructure = document.getElementById('filterInfrastructure').checked;
    const showAttractions = document.getElementById('filterAttractions').checked;
    const showRoutes = document.getElementById('filterRoutes').checked;

    // Обновление счетчика активных фильтров
    const activeCount = [showZones, showInfrastructure, showAttractions, showRoutes]
        .filter(Boolean).length;
    document.getElementById('activeFilters').textContent = activeCount;

    // Применение фильтров к карте
    applyMapFilters(showZones, showAttractions);
}

// Применение фильтров к карте
function applyMapFilters(showZones, showAttractions) {
    if (markers.zones) {
        markers.zones.forEach(zone => {
            if (showZones) {
                map.addLayer(zone);
            } else {
                map.removeLayer(zone);
            }
        });
    }

    if (markers.attractions) {
        markers.attractions.forEach(marker => {
            if (showAttractions) {
                map.addLayer(marker);
            } else {
                map.removeLayer(marker);
            }
        });
    }
}

// Обновление времени
function updateTime() {
    const now = new Date();
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };

    const timeString = now.toLocaleDateString('ru-RU', options);
    document.getElementById('currentTime').textContent = `Обновлено: ${timeString}`;
}

// Вспомогательные функции
function getMonthName(month) {
    const months = [
        'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
        'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
    ];
    return months[month - 1] || 'Неизвестный месяц';
}

// Экспорт функций для глобального использования
window.checkAccessForAttraction = checkAccessForAttraction;
window.showAttractionInfo = showAttractionInfo;
window.zoomToAttraction = zoomToAttraction;


async function generateSmartRoute() {
    const resultDiv = document.getElementById('accessResult');
    resultDiv.className = 'access-result';
    resultDiv.innerHTML = '<div class="loading">🔄 Генерация...</div>';

    const params = {
        theme: 'ледники',
        experience_level: document.getElementById('experienceLevel')?.value || 'beginner',
        month: parseInt(document.getElementById('monthSelect')?.value) || 7,
        group_size: parseInt(document.getElementById('groupSize')?.value) || 10,
        transport_type: 'пеший'
    };

    try {
        const qs = new URLSearchParams(params).toString();
        const res = await fetch(`${CONFIG.API_URL}/generate_smart_route?${qs}`);
        const result = await res.json();

        if (!res.ok) throw new Error(result.detail || 'Ошибка');

        const warnings = (result.warnings || []).map(w => `<div style="background:#fff3cd;padding:5px;margin:3px 0;border-radius:3px">⚠️ ${w}</div>`).join('');
        const points = (result.points || []).map((p, i) => `<div><b>${i + 1}. ${p.name}</b><br><small>🏔️${p.elevation_m}м | 👟${p.trail_difficulty}</small></div>`).join('');

        resultDiv.className = 'access-result allowed';
        resultDiv.innerHTML = `
            <h4 style="margin:0 0 10px; color:#2c3e50">✅ ${result.route_name}</h4>
            
            <div style="background:#f8f9fa; padding:10px; border-radius:8px; margin-bottom:10px; font-size:14px; line-height:1.5">
                <div style="margin-bottom:6px">
                    <strong> Дневной лимит:</strong> ${result.base_daily_limit_km} км 
                    ${result.base_daily_limit_km !== result.effective_daily_limit_km
                ? `<span style="color:#e74c3c">→ ${result.effective_daily_limit_km} км</span> <small>(снижен из-за сложности)</small>`
                : `<span style="color:#27ae60">(оптимально)</span>`}
                </div>
                <div><strong>🛤️ Общая дистанция:</strong> ${result.total_distance_km} км</div>
            </div>

            ${(result.warnings || []).length > 0 ? `
            <div style="background:#fff3cd; padding:10px; border-radius:8px; margin-bottom:10px; font-size:13px">
                <strong>Рекомендации:</strong>
                ${result.warnings.map(w => `<div style="margin-top:6px">• ${w}</div>`).join('')}
            </div>` : ''}

            <div style="font-size:14px">
                <strong> Точки маршрута:</strong>
                <ol style="margin:8px 0 0 20px; padding:0">
                    ${(result.points || []).map(p => `<li style="margin-bottom:4px">${p.name} <small style="color:#7f8c8d">(${p.trail_difficulty})</small></li>`).join('')}
                </ol>
            </div>
            
            <button class="btn-primary" style="margin-top:12px; width:100%" onclick="window.zoomToRoute()">
                🗺️ Показать маршрут на карте
            </button>
        `;

        displayRouteOnMap(result.points);

    } catch (e) {
        resultDiv.className = 'access-result denied';
        resultDiv.innerHTML = `<h4>❌ Ошибка</h4><p>${e.message}</p>`;
        console.error(e);
    }
}

// 🆕 Отрисовка маршрута на карте
// Глобальные переменные для хранения слоя и маркеров маршрута
window.routeLayer = null;
window.routeMarkers = [];

function displayRouteOnMap(points) {
    // 1. Очищаем старую линию
    if (window.routeLayer) {
        map.removeLayer(window.routeLayer);
        window.routeLayer = null;
    }
    // 2. Очищаем старые маркеры (это решало проблему с "4 точками на карте")
    window.routeMarkers.forEach(marker => map.removeLayer(marker));
    window.routeMarkers = [];

    if (!points || points.length === 0) return;

    // 3. Подготовка координат: Leaflet ждёт [широта, долгота], у нас в JSON [долгота, широта]
    const coords = points.map(p => [p.coordinates[1], p.coordinates[0]]);

    // 4. Рисуем линию только если точек >= 2
    if (points.length >= 2) {
        window.routeLayer = L.polyline(coords, {
            color: '#e74c3c', weight: 4, opacity: 0.8, dashArray: '10,10'
        }).addTo(map);
    }


    points.forEach((p, i) => {
        const marker = L.marker([p.coordinates[1], p.coordinates[0]], {
            icon: L.divIcon({
                html: `<div style="background:#e74c3c;color:white;width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;border:2px solid white">${i + 1}</div>`,
                iconSize: [26, 26], iconAnchor: [13, 13], className: ''
            })
        }).addTo(map).bindPopup(`<b>${p.name}</b><br>🏔️ ${p.elevation_m} м`);
        window.routeMarkers.push(marker);
    });


    if (window.routeLayer) {
        map.fitBounds(window.routeLayer.getBounds(), { padding: [50, 50] });
    } else if (points.length === 1) {
        map.setView(coords[0], 13);
    }
}

window.zoomToRoute = function () {
    if (routeLayer) map.fitBounds(routeLayer.getBounds(), { padding: [50, 50] });
};

//  Генерация умного маршрута (безопасная версия)
async function generateSmartRoute() {
    const resultDiv = document.getElementById('accessResult');
    if (!resultDiv) return;

    resultDiv.className = 'access-result';
    resultDiv.innerHTML = '<div class="loading">🔄 Генерация...</div>';

    const themeValue = document.getElementById('routeTheme')?.value || 'все';

    const params = {
        theme: themeValue === 'все' ? '' : themeValue,  // 🔥 Пустая строка = все темы
        experience_level: document.getElementById('experienceLevel')?.value || 'beginner',
        month: parseInt(document.getElementById('monthSelect')?.value) || 7,
        group_size: parseInt(document.getElementById('groupSize')?.value) || 10,
        transport_type: 'пеший'
    };
    try {
        const qs = new URLSearchParams(params).toString();
        const res = await fetch(`${CONFIG.API_URL}/generate_smart_route?${qs}`);
        const result = await res.json();

        if (!res.ok) throw new Error(result.detail || 'Ошибка API');

        // Формируем HTML результата
        const warnings = (result.warnings || []).map(w => `<div style="background:#fff3cd;padding:5px;margin:3px 0;border-radius:3px;font-size:13px"> ${w}</div>`).join('');
        const pointsList = (result.points || []).map((p, i) => `<div style="padding:4px 0;border-bottom:1px dashed #ddd"><b>${i + 1}. ${p.name}</b> <small>${p.trail_difficulty}</small></div>`).join('');

        resultDiv.className = 'access-result allowed';
        resultDiv.innerHTML = `
            <h4 style="margin:0 0 8px"> ${result.route_name}</h4>
            <div style="background:#e8f5e9;padding:8px;border-radius:6px;margin:8px 0;font-size:13px">
                <b> Лимит:</b> ${result.base_daily_limit_km} → ${result.effective_daily_limit_km} км/день<br>
                <b> Корректировка:</b> ${result.difficulty_adjustment}<br>
                <b> Дистанция:</b> ${result.total_distance_km} км
            </div>
            ${warnings ? `<div style="margin:8px 0"><b> Предупреждения:</b>${warnings}</div>` : ''}
            <div style="margin:8px 0"><b> Точки маршрута:</b>${pointsList}</div>
            <button class="btn-primary" style="margin-top:8px;font-size:13px" onclick="zoomToRoute()">🗺️ Показать на карте</button>
        `;

        if (window.displayRouteOnMap) window.displayRouteOnMap(result.points);

    } catch (e) {
        resultDiv.className = 'access-result denied';
        resultDiv.innerHTML = `<h4>❌ Ошибка</h4><p style="font-size:13px">${e.message}</p>`;
        console.error('Route generation error:', e);
    }
}

window.displayRouteOnMap = function (points) {
    if (!map || !points || points.length < 2) return;

    // Очищаем старый маршрут
    if (window._routeLayer) { map.removeLayer(window._routeLayer); window._routeLayer = null; }
    if (window._routeMarkers) { window._routeMarkers.forEach(m => map.removeLayer(m)); window._routeMarkers = []; }

    const coords = points.map(p => [p.coordinates[1], p.coordinates[0]]);

    // Линия маршрута
    window._routeLayer = L.polyline(coords, { color: '#e74c3c', weight: 3, opacity: 0.8, dashArray: '8,8' }).addTo(map);

    // Маркеры с номерами
    window._routeMarkers = points.map((p, i) => {
        return L.marker([p.coordinates[0], p.coordinates[1]], {
            icon: L.divIcon({
                html: `<div style="background:#e74c3c;color:white;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:12px;border:2px solid white">${i + 1}</div>`,
                iconSize: [24, 24], iconAnchor: [12, 12], className: ''
            })
        }).addTo(map).bindPopup(`<b>${p.name}</b>`);
    });

    map.fitBounds(window._routeLayer.getBounds(), { padding: [40, 40] });
};

window.zoomToRoute = function () {
    if (window._routeLayer) map.fitBounds(window._routeLayer.getBounds(), { padding: [40, 40] });
};

const filterInfrastructureCheckbox = document.getElementById('filterInfrastructure');

// Функция применения фильтров
function applyInfrastructureFilter() {
    const showInfrastructure = filterInfrastructureCheckbox?.checked !== false;
    displayAttractionsOnMap(showInfrastructure);
}

// Обработчик изменения чекбокса
if (filterInfrastructureCheckbox) {
    filterInfrastructureCheckbox.addEventListener('change', () => {
        console.log('🔧 Фильтр инфраструктуры:', filterInfrastructureCheckbox.checked ? 'вкл' : 'выкл');
        applyInfrastructureFilter();
    });
}

console.log('Приложение успешно загружено!');
window.showAttractionInfoByName = showAttractionInfoByName;