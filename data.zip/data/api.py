from fastapi import FastAPI, HTTPException
import json
import os
from geopy.distance import geodesic

app = FastAPI(title="EcoRoute API", description="AI для экологически безопасных маршрутов в Приэльбрусье")

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
ZONE_RULES = json.load(open(os.path.join(DATA_DIR, 'zones', 'zone_rules.json'), encoding='utf-8'))
SEASONAL_RULES = json.load(open(os.path.join(DATA_DIR, 'rules', 'seasonal_rules.json'), encoding='utf-8'))
TRANSPORT_RULES = json.load(open(os.path.join(DATA_DIR, 'rules', 'transport_rules.json'), encoding='utf-8'))
POINTS = json.load(open(os.path.join(DATA_DIR, 'points', 'attractions.json'), encoding='utf-8'))

ALLOWED_TRANSPORT = list(TRANSPORT_RULES["allowed_transport"].keys())

def validate_point(zone_type: str, group_size: int, month: int, transport_type: str, avalanche_risk: int, elevation_m: int) -> dict:
    """Проверяет доступ к точке по ВСЕМ правилам, включая лавины"""
    # 1. Проверка группы
    if group_size > ZONE_RULES[zone_type]["max_group_size"]:
        return {"allowed": False, "reason": f"Группа превышает лимит (макс. {ZONE_RULES[zone_type]['max_group_size']})"}
    
    # 2. Проверка сезона
    for season, data in SEASONAL_RULES["seasonal_restrictions"].items():
        if month in data["months"] and zone_type in data["restricted_zones"]:
            return {"allowed": False, "reason": f"Зона закрыта {season} для защиты экосистемы"}
    
    # 3. Проверка транспорта
    if transport_type not in TRANSPORT_RULES["allowed_transport"]:
        return {"allowed": False, "reason": f"Недопустимый тип транспорта '{transport_type}'"}
    
    if zone_type not in TRANSPORT_RULES["allowed_transport"][transport_type]:
        return {"allowed": False, "reason": f"В зоне '{zone_type}' запрещён {transport_type} (ст. 15 п.1 ФЗ-33)"}
    
    # 4. ПРОВЕРКА ЛАВИННОЙ ОПАСНОСТИ 
    if avalanche_risk >= 4 and elevation_m > 2500:
        return {
            "allowed": False, 
            "reason": f"ЛАВИННАЯ ОПАСНОСТЬ! Высота {elevation_m} м превышает безопасный предел при риске {avalanche_risk}/5 (Приказ МЧС № 12-3/5 от 15.01.2023)"
        }
    
    return {"allowed": True, "reason": "OK"}

def matches_theme(point: dict, theme: str) -> bool:
    educational_value = point.get("educational_value", "").lower()
    tags = [tag.strip() for tag in educational_value.split(",")]
    return any(theme.lower() in tag for tag in tags)

@app.get("/generate_route")
def generate_route(
    difficulty: str = "easy",
    theme: str = "ледники",
    group_size: int = 10,
    month: int = 7,
    transport_type: str = "пеший",
    avalanche_risk: int = 1  
):
    """
    Генерирует маршрут с учётом:
    - Типа транспорта
    - Уровня лавинной опасности (1-5)
    Поддерживаемые транспорт: пеший велосипед лошади автомобиль, канатная дорога
    """
    # Валидация уровня опасности
    if not 1 <= avalanche_risk <= 5:
        raise HTTPException(
            status_code=400,
            detail="Уровень лавинной опасности должен быть от 1 до 5"
        )
    
    # Валидация транспорта
    if transport_type.strip().lower() not in [t.strip().lower() for t in ALLOWED_TRANSPORT]:
        raise HTTPException(
            status_code=400,
            detail=f"Недопустимый тип транспорта. Доступные варианты: {', '.join(ALLOWED_TRANSPORT)}"
        )
    
    # Фильтрация точек
    valid_points = [p for p in POINTS["points"] if matches_theme(p, theme)]
    if len(valid_points) < 2:
        raise HTTPException(
            status_code=404, 
            detail=f"Недостаточно точек по теме '{theme}'. Попробуйте: ледники, альпинизм, этнография"
        )
    
    route_points = valid_points[:2]
    
    for point in route_points:
        validation = validate_point(
            point["zone_type"], 
            group_size, 
            month, 
            transport_type,
            avalanche_risk,
            point["elevation_m"]  
        )
        if not validation["allowed"]:
            raise HTTPException(
                status_code=400,
                detail=f"Точка '{point['name']}' недоступна: {validation['reason']}"
            )
    
    # Расчёт расстояния
    p1 = (route_points[0]["coordinates"][1], route_points[0]["coordinates"][0])
    p2 = (route_points[1]["coordinates"][1], route_points[1]["coordinates"][0])
    total_distance = geodesic(p1, p2).km
    
    # Расчёт углеродного следа 
    carbon_coefficients = {
        "пеший": 0.01,
        "велосипед": 0.02,
        "лошади": 0.10,
        "автомобиль": 0.25,
        "канатная дорога": 0.05
    }
    carbon_footprint = round(total_distance * carbon_coefficients[transport_type], 2)
    
    return {
        "route_name": f"Эко-маршрут «{theme.capitalize()}» на {transport_type} ({difficulty})",
        "points": [
            {
                "name": p["name"],
                "coordinates": [p["coordinates"][0], p["coordinates"][1]],
                "description": p["description"],
                "elevation_m": p["elevation_m"],
                "warning": "Требуется гид" if ZONE_RULES[p["zone_type"]].get("requires_guide") else None
            }
            for p in route_points
        ],
        "total_distance_km": round(total_distance, 1),
        "carbon_footprint_kg": carbon_footprint,
        "eco_recommendation": f"Пеший маршрут снизил бы углеродный след на {round((carbon_coefficients[transport_type] - carbon_coefficients['пеший']) / carbon_coefficients[transport_type] * 100)}%!",
        "avalanche_safety": f"Уровень лавинной опасности: {avalanche_risk}/5. Выше 2500 м запрещено при риске ≥4.",
        "eco_score": 95,
        "warnings": [
            "Движение ТОЛЬКО по разрешённому транспорту (ст. 15 п.1 ФЗ-33)",
            "Запрещена добыча растений и минералов (ст. 9 п.1 ФЗ-33)",
            "Лавинная безопасность определяется по Приказу МЧС № 12-3/5"
        ]
    }