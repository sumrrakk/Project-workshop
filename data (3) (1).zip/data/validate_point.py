import json
import os

current_dir = os.path.dirname(os.path.abspath(__file__))

with open(os.path.join(current_dir, 'zones', 'zone_rules.json'), 'r', encoding='utf-8') as f:
    ZONE_RULES = json.load(f)

with open(os.path.join(current_dir, 'rules', 'seasonal_rules.json'), 'r', encoding='utf-8') as f:
    SEASONAL_RULES = json.load(f)

def is_point_accessible(zone_type: str, group_size: int, month: int) -> dict:
    """
    Проверяет можно ли посетить точку с заданными параметрами.
    Возвращает словарь с результатом и причиной отказа если она есть.
    """
    # Проверка 1: Размер группы
    if group_size > ZONE_RULES[zone_type]["max_group_size"]:
        return {
            "allowed": False,
            "reason": f"Группа превышает лимит ({group_size} > {ZONE_RULES[zone_type]['max_group_size']})"
        }
    
    # Проверка 2: Сезон
    for season_data in SEASONAL_RULES["seasonal_restrictions"].values():
        if month in season_data["months"] and zone_type in season_data["restricted_zones"]:
            season_name = [k for k, v in SEASONAL_RULES["seasonal_restrictions"].items() if v == season_data][0]
            return {
                "allowed": False,
                "reason": f"Зона закрыта в {season_name} для защиты экосистемы"
            }
    
    return {"allowed": True, "reason": "Доступ разрешён"}

# Тест 1: Попытка группы 10 человек в заповедную зону летом (июль)
print("Тест 1 — Эльбрус, 10 человек, июль:")
result1 = is_point_accessible("заповедная", 10, 7)
print(f"Результат: {result1['allowed']}, Причина: {result1['reason']}")

# Тест 2: Группа 5 человек в особо охраняемой зоне зимой (январь)
print("\nТест 2 — Долина Нарзанов, 5 человек, январь:")
result2 = is_point_accessible("особо охраняемая", 5, 1)
print(f"Результат: {result2['allowed']}, Причина: {result2['reason']}")

# Тест 3: Группа 20 человек в рекреационной зоне летом (июль)
print("\nТест 3 — Чегет, 20 человек, июль:")
result3 = is_point_accessible("рекреационная", 20, 7)
print(f"Результат: {result3['allowed']}, Причина: {result3['reason']}")