import geojson
import os

script_dir = os.path.dirname(os.path.abspath(__file__))


output_path = os.path.join(script_dir, 'functional_zones.geojson')

zones = [
    {
        "name": "Заповедная зона (Эльбрус)",
        "zone_type": "заповедная",
        "coordinates": [
            [43.34, 42.42], [43.36, 42.42], [43.36, 42.46], [43.34, 42.46], [43.34, 42.42]
        ],
        "properties": {
            "restriction_level": 5,
            "allowed_activities": ["научные исследования"],
            "max_group_size": 5,
            "requires_permission": True
        }
    },
    {
        "name": "Рекреационная зона (Чегет)",
        "zone_type": "рекреационная",
        "coordinates": [
            [43.30, 42.38], [43.33, 42.38], [43.33, 42.42], [43.30, 42.42], [43.30, 42.38]
        ],
        "properties": {
            "restriction_level": 2,
            "allowed_activities": ["туризм", "фотосъемка", "экопросвещение"],
            "max_group_size": 30,
            "requires_permission": False
        }
    },
    {
        "name": "Зона традиционного природопользования",
        "zone_type": "традиционного природопользования",
        "coordinates": [
            [43.38, 42.46], [43.40, 42.46], [43.40, 42.50], [43.38, 42.50], [43.38, 42.46]
        ],
        "properties": {
            "restriction_level": 1,
            "allowed_activities": ["туризм", "традиционное хозяйство"],
            "max_group_size": 50,
            "requires_permission": False
        }
    }
]

features = []
for zone in zones:
    polygon = geojson.Polygon([zone["coordinates"]])
    feature = geojson.Feature(
        geometry=polygon,
        properties={
            "name": zone["name"],
            "zone_type": zone["zone_type"],
            **zone["properties"]
        }
    )
    features.append(feature)

feature_collection = geojson.FeatureCollection(features)

with open(output_path, 'w', encoding='utf-8') as f:
    geojson.dump(feature_collection, f, ensure_ascii=False, indent=2)

print(f" Файл успешно сохранен: {output_path}")
print(" Теперь файл лежит в корне папки zones")