from fastapi import FastAPI
import json
import os

app = FastAPI()

current_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(current_dir, 'zones', 'zone_rules.json'), 'r', encoding='utf-8') as f:
    ZONE_RULES = json.load(f)
with open(os.path.join(current_dir, 'rules', 'seasonal_rules.json'), 'r', encoding='utf-8') as f:
    SEASONAL_RULES = json.load(f)

def is_point_accessible(zone_type: str, group_size: int, month: int) -> dict:
    if group_size > ZONE_RULES[zone_type]["max_group_size"]:
        return {"allowed": False, "reason": f"Группа превышает лимит"}
    for season_data in SEASONAL_RULES["seasonal_restrictions"].values():
        if month in season_data["months"] and zone_type in season_data["restricted_zones"]:
            return {"allowed": False, "reason": f"Зона закрыта в этот сезон"}
    return {"allowed": True, "reason": "OK"}

@app.get("/check_access")
def check_access(zone_type: str, group_size: int, month: int):
    """Проверяет доступ к зоне через API"""
    return is_point_accessible(zone_type, group_size, month)